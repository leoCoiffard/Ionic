import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)},
  {
    path: 'galerie',
    loadChildren: () => import('./galerie/galerie.module').then( m => m.GaleriePageModule)
  },
  {
    path: 'meteo',
    loadChildren: () => import('./meteo/meteo.module').then( m => m.MeteoPageModule)
  },
  {
    path: 'lieux',
    loadChildren: () => import('./lieux/lieux.module').then( m => m.LieuxPageModule)
  },
  {
    path: 'details-image',
    loadChildren: () => import('./details-image/details-image.module').then( m => m.DetailsImagePageModule)
  },
  {
    path: 'add-lieux',
    loadChildren: () => import('./add-lieux/add-lieux.module').then( m => m.AddLieuxPageModule)
  },
  {
    path: 'details-lieux',
    loadChildren: () => import('./details-lieux/details-lieux.module').then( m => m.DetailsLieuxPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
