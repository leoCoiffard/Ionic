import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GalerieService {
  urlPixabayApi = 'https://pixabay.com/api/';
  apiKey = '15549634-be9ca135b6e9b8ea8291ea552';

  private imageSelected: any;

  constructor(public http: HttpClient) { }

  searchPixabay(query: string , size: number, page: number) {
    const req = `${this.urlPixabayApi}?key=${this.apiKey}&q=${query}&per_page=${size}&page=${page}&lang=fr`;
    return this.http.get(req);
  }
  defineImage(image: any) {
    this.imageSelected = image;
  }
  getImage() {
    return this.imageSelected;
  }
}
