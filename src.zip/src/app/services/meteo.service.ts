import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MeteoService {

  urlMeteoApi = 'http://api.openweathermap.org/data/2.5/forecast';
  apiKey = '3c6736c5d46bf0014bd7c897cd71f0c5';
  constructor(public http: HttpClient) { }

  searchMeteo(query: string) {
    const req = `${this.urlMeteoApi}?q=${query}&appid=${this.apiKey}&units=metric`;
    console.log(req);
    return this.http.get(req);
  }
}
