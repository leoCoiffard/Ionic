import { Lieu } from './../lieu.model';
import { Injectable } from '@angular/core';
import { Plugins } from '@capacitor/core';

const { Storage } = Plugins;

@Injectable({
  providedIn: 'root'
})
export class LieuxService {
  private lieux: Array<Lieu> = [];

  private lieuSelected: any;

  constructor() { }

    getLieux(): Promise<any> {
    return Storage.get({key: 'lieux'}).then(datas => {
    this.lieux = datas.value !== null ? JSON.parse(datas.value) : [];
    return this.lieux;
    });
  }
  async addLieu(lieu: Lieu) {
    this.lieux.push(lieu);
    await Storage.set({
      key: 'lieux',
      value: JSON.stringify(this.lieux)
    });
  }
  defineLieu(lieu: any) {
    this.lieuSelected = lieu;
  }

  getlieu() {
    return this.lieuSelected;
  }
}
