import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AddLieuxPage } from './add-lieux.page';

const routes: Routes = [
  {
    path: '',
    component: AddLieuxPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AddLieuxPageRoutingModule {}
