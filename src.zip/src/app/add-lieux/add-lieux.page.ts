import { Lieu } from './../lieu.model';
import { LieuxService } from './../services/lieux.service';
import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { Plugins } from '@capacitor/core';

const { Geolocation } = Plugins;

@Component({
  selector: 'app-add-lieux',
  templateUrl: './add-lieux.page.html',
  styleUrls: ['./add-lieux.page.scss'],
})
export class AddLieuxPage {

  constructor(private lieuxService: LieuxService, private navCtrl: NavController) { }

  async addLieu(lieu: Lieu) {
    lieu.creatingDate = new Date().getTime();
    lieu.location = {latitude : 0 , longitude: 0 };
    Geolocation.getCurrentPosition().then(datas => {
      lieu.location.latitude = datas.coords.latitude;
      lieu.location.longitude = datas.coords.longitude;
      this.afterLocation(lieu);
    }).catch(err => {
      console.log(err);
      this.afterLocation(lieu);
    });
  }
  private afterLocation(lieu: Lieu) {
    this.lieuxService.addLieu(lieu);
    this.navCtrl.navigateBack('/lieux');
  }
}
