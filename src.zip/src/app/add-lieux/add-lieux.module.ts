import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AddLieuxPageRoutingModule } from './add-lieux-routing.module';

import { AddLieuxPage } from './add-lieux.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AddLieuxPageRoutingModule
  ],
  declarations: [AddLieuxPage]
})
export class AddLieuxPageModule {}
