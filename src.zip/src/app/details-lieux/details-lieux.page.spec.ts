import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { DetailsLieuxPage } from './details-lieux.page';

describe('DetailsLieuxPage', () => {
  let component: DetailsLieuxPage;
  let fixture: ComponentFixture<DetailsLieuxPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetailsLieuxPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(DetailsLieuxPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
