import { Component, OnInit } from '@angular/core';
import { LieuxService } from '../services/lieux.service';

@Component({
  selector: 'app-details-lieux',
  templateUrl: './details-lieux.page.html',
  styleUrls: ['./details-lieux.page.scss'],
})
export class DetailsLieuxPage implements OnInit {
  lieu: any;
  constructor(private lieuxService: LieuxService) { }

  ngOnInit() {
    this.lieu = this.lieuxService.getlieu();
    console.log(this.lieu);
  }

}
