import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DetailsLieuxPage } from './details-lieux.page';

const routes: Routes = [
  {
    path: '',
    component: DetailsLieuxPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DetailsLieuxPageRoutingModule {}
