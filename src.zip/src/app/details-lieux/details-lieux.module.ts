import { AgmCoreModule } from '@agm/core';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DetailsLieuxPageRoutingModule } from './details-lieux-routing.module';

import { DetailsLieuxPage } from './details-lieux.page';




@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DetailsLieuxPageRoutingModule,
    AgmCoreModule
  ],
  declarations: [DetailsLieuxPage]
})
export class DetailsLieuxPageModule {}
