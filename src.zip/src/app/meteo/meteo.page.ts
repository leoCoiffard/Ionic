import { MeteoService } from './../services/meteo.service';
import { Component, OnInit } from '@angular/core';
import { LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-meteo',
  templateUrl: './meteo.page.html',
  styleUrls: ['./meteo.page.scss'],
})
export class MeteoPage implements OnInit {
  searchTerm = '';
  resultMeteo: any;
  constructor(public service: MeteoService,
              public loadingController: LoadingController) { }

  ngOnInit() {
  }
  async search() {
    const loading = await this.loadingController.create({
      message: 'Chargement en cours...',
    });
    loading.present().then(() => {
      this.service.searchMeteo(this.searchTerm).subscribe((datas: any) => {
        this.resultMeteo = datas;
        loading.dismiss();
    }, err => {
      loading.dismiss();
      console.log(err);
    });
});

}
}
