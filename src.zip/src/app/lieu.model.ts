export class Lieu {
    title: string;
    country?: string;
    city?: string;
    creatingDate?: number;
    keyword?: string;
    location?: {
        latitude: number,
        longitude: number
    };
    photo?: string[];
}
